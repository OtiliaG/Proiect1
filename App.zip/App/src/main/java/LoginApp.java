import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class LoginApp {
    public static void main(String[] args) throws SQLException {
        Connection connection = DriverManager.getConnection
                ("jdbc:mysql://127.0.0.1:3306/app", "root", "otilia1313");
        System.out.println("Introdu o optiune: 1-Inregistare, 2-Login, 3-Resetare parola");
        Scanner scanner = new Scanner(System.in);
        int optiune = scanner.nextInt();
        switch (optiune) {
            case 1:
                System.out.println("Introdu un unsername");
                String username = scanner.next();
                System.out.println("Introdu o parola");
                String password = scanner.next();

                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery("select username from user");
                List <String> usernamesFromTableUser = new ArrayList<>();
                //salvez in lista ce citesc din tabela
                while (resultSet.next()){
                    String usernameFromTable = resultSet.getString("username");
                    usernamesFromTableUser.add(usernameFromTable);
                }
                //verific daca in lista exista un user identic cu ce a introdus utilizatorul
                if (usernamesFromTableUser.contains(username)){
                    System.out.println("Username invalid");
                }else{
                    String queryInsert =
                            String.format("insert into user values (null, '%s','%s')",
                                    username, password);

                    int rezultat = statement.executeUpdate(queryInsert);
                    if (rezultat>=1){
                        System.out.println("Utilizatorul a fost adaugat cu succes");
                    }else {
                        System.out.println("A aparut o eroare");
                    }
                }

                break;

            case 2:
                System.out.println("Introdu un unsername pentru login");
                String usernameLogin = scanner.next();
                System.out.println("Introdu o parola pentru login");
                String passwordLogin = scanner.next();

                User userIntrodusDeLaTastatura = new User();
                userIntrodusDeLaTastatura.setUsername(usernameLogin);
                userIntrodusDeLaTastatura.setPassword(passwordLogin);

                Statement statement2 = connection.createStatement();
                ResultSet resultSet2 = statement2.executeQuery("select * from user");
                List<User> users = new ArrayList<>();

                while (resultSet2.next()){
                    String usernameLoginDB = resultSet2.getString("username");
                    String passwordLoginDB = resultSet2.getString("password");
                    User user = new User();
                    user.setPassword(passwordLoginDB);
                    user.setUsername(usernameLoginDB);
                    users.add(user);
                }
                //validez utilizatorul


                boolean logged = false;
//                for (User user : users){
//                    if(user.getUsername().equals(usernameLogin) & user.getPassword().equals(passwordLogin)){
//                        //System.out.println("Te-ai logat cu succes");
//                      logged = true;
//                    }
////                    else{
////                        //System.out.println("Credentiale incorecte");
////                    }
//
//                }
//                if (logged){
//                    System.out.println("Te-ai logat cu succes");
//                }else {
//                    System.out.println("Credentiale incorecte");
//                }
                if (users.contains(userIntrodusDeLaTastatura)){
                    System.out.println("Te-ai logat cu succes");
                }else{
                    System.out.println("Credentiale incorecte");
                }

                break;

            case 3:
                System.out.println("Pentru resetarea parolei, introdu username-ul");
                username = scanner.next();
                System.out.println("Introdu noua parola");
                password = scanner.next();
                String queryUpdate = String.format("update user set password = '%s' where username = '%s'", password, username);
                Statement statement3 = connection.createStatement();
                int resultUpdate = statement3.executeUpdate(queryUpdate);
                if (resultUpdate==1){
                    System.out.println("Parola a fost actualizata cu succes");
                }else{
                    System.out.println("A aparut o eroare in resetarea parolei");
                }
                break;

        }
    }
}
